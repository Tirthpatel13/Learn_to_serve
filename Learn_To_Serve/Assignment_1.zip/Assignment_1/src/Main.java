import java.util.*;

public class Main {
    public static void main(String[] args) {

        System.out.println("1. Write a program to check if two LinkedLists are equal.");
        List<Integer> list1 = new LinkedList<Integer>();
        List<Integer> list2 = new LinkedList<Integer>();
        list1.add(Integer.valueOf(1));
        list1.add(Integer.valueOf(2));
        list1.add(Integer.valueOf(3));
        list2.add(Integer.valueOf(1));
        list2.add(Integer.valueOf(2));
        list2.add(Integer.valueOf(3));

        boolean Q1 = question_1.areIdentical(list1, list2);
        if(Q1){
            System.out.println("Lists are identical.");
        }
        else{
            System.out.println("Lists are not identical.");
        }
        System.out.println("----------------------------------------------------------------------");

        System.out.println("2. Check weather an array list is subset of another array list");
        List<Integer> list3 = new ArrayList<>();
        List<Integer> list4 = new ArrayList<>();
        list3.add(Integer.valueOf(1));
        list3.add(Integer.valueOf(2));
        list3.add(Integer.valueOf(3));
        list3.add(Integer.valueOf(4));
        list4.add(Integer.valueOf(1));
        list4.add(Integer.valueOf(2));
        list4.add(Integer.valueOf(4));

        boolean Q2 = question_2.isSubset(list3, list4);
        if(Q2){
            System.out.println("Lists are subset of another array list.");
        }
        else{
            System.out.println("Lists are not subset of another array list.");
        }
        System.out.println("-----------------------------------------------------------------------");

        System.out.println("3. Write a program to get set of keys and values of hashmap ");
        Map<Integer,Integer> map = new HashMap<>();
        map.put(Integer.valueOf(1), 1);
        map.put(Integer.valueOf(2), 2);
        map.put(Integer.valueOf(3), 3);
        map.put(Integer.valueOf(4), 4);
        System.out.println(question_3.SetAndValue(map));

        System.out.println("-----------------------------------------------------------------------");

        System.out.println("4. check if string array has duplicates using hashsets");
        String[] a = new String[10];
        a[0] = "apple";
        a[1] = "";
        a[2] = "banana";
        a[3] = "apple";
        a[4] = "cherry";
        a[5] = "banana";
        a[6] = "date";
        a[7] = "cherry";
        a[8] = "fig";
        a[9] = "grape";

        System.out.println(question_4.isduplicate(a));
        System.out.println("------------------------------------------------------------------------");
        System.out.println("5. Copy string array to list and back to array ");
        System.out.println(question_5.ALA(a));


    }
}